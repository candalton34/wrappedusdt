# Wrapped USDT (Wormhole) - wUSDT Token Website

## Overview

This is a full-stack web application for the Wrapped USDT (Wormhole) token website. The application is built using a modern tech stack with React frontend, Express backend, and PostgreSQL database with Drizzle ORM. The project features a clean, professional design with a Tether green color scheme and comprehensive UI components.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Bundler**: Vite for fast development and optimized builds
- **Routing**: Wouter for lightweight client-side routing
- **State Management**: TanStack Query (React Query) for server state management
- **Styling**: Tailwind CSS with custom Tether green theme
- **UI Components**: shadcn/ui component library with Radix UI primitives
- **Forms**: React Hook Form with Zod validation via @hookform/resolvers

### Backend Architecture
- **Runtime**: Node.js 20 with TypeScript
- **Framework**: Express.js with ESM modules
- **Database ORM**: Drizzle ORM with PostgreSQL dialect
- **Database Provider**: Neon Database (@neondatabase/serverless)
- **Session Management**: Connect-pg-simple for PostgreSQL session storage
- **Development**: tsx for TypeScript execution

### Data Storage
- **Primary Database**: PostgreSQL 16
- **ORM**: Drizzle ORM with type-safe queries
- **Migrations**: Drizzle Kit for schema management
- **Connection**: Neon serverless driver for optimized database connections
- **Session Storage**: PostgreSQL-backed sessions via connect-pg-simple

## Key Components

### Database Schema
- **Users Table**: Basic user management with id, username, and password fields
- **Schema Validation**: Zod schemas generated from Drizzle tables for type safety

### Storage Layer
- **Interface**: IStorage abstraction for CRUD operations
- **Implementation**: MemStorage class for in-memory development storage
- **Methods**: getUser, getUserByUsername, createUser

### Frontend Pages
- **Home Page**: Main landing page with token information and contract details
- **404 Page**: Error handling for undefined routes

### UI Components
- Comprehensive shadcn/ui component library
- Custom toast notifications system
- Mobile-responsive design with useIsMobile hook
- Accessible form components with proper validation

## Data Flow

1. **Client Requests**: Frontend makes API calls using TanStack Query
2. **API Layer**: Express server handles requests with proper error handling
3. **Storage Layer**: Storage interface abstracts database operations
4. **Database**: PostgreSQL stores persistent data via Drizzle ORM
5. **Response**: JSON responses sent back to client with proper error handling

## External Dependencies

### Core Dependencies
- **Database**: @neondatabase/serverless for PostgreSQL connection
- **ORM**: drizzle-orm and drizzle-zod for database operations
- **UI**: Comprehensive Radix UI component primitives
- **State**: @tanstack/react-query for server state management
- **Styling**: Tailwind CSS with class-variance-authority for component variants

### Development Tools
- **Build**: Vite with React plugin and runtime error overlay
- **TypeScript**: Full type safety across frontend and backend
- **Linting**: ESM modules with strict TypeScript configuration

## Deployment Strategy

### Build Process
- **Frontend**: Vite builds optimized static assets to `dist/public`
- **Backend**: esbuild bundles server code to `dist/index.js`
- **Database**: Drizzle migrations stored in `./migrations`

### Environment Configuration
- **Development**: `npm run dev` runs tsx server with hot reload
- **Production**: `npm start` runs compiled Node.js application
- **Database**: `npm run db:push` applies schema changes

### Hosting
- **Platform**: Replit autoscale deployment
- **Port Configuration**: Internal port 5000, external port 80
- **Static Assets**: Served from `dist/public` directory

## Recent Changes

✓ Complete wUSDT website implementation with professional design
✓ Integrated custom logo and branding elements  
✓ Added contact information and owner address display
✓ Comprehensive whitepaper with tokenomics (10B supply, 2B Jupiter liquidity)
✓ Applied Tether green color theme throughout
✓ Added download source code functionality for visitors
✓ Prepared Git repository with proper .gitignore and documentation
✓ Ready for GitHub upload and deployment on Netlify/Vercel

## Changelog

- June 24, 2025: Initial wUSDT website setup and deployment preparation

## User Preferences

Preferred communication style: Simple, everyday language.