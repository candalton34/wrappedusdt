#!/bin/bash

# wUSDT Website Export Script
echo "Creating project export..."

# Create export directory
mkdir -p wusdt-export

# Copy all necessary files
cp -r client wusdt-export/
cp -r server wusdt-export/
cp -r shared wusdt-export/
cp -r attached_assets wusdt-export/
cp package.json wusdt-export/
cp package-lock.json wusdt-export/
cp vite.config.ts wusdt-export/
cp tsconfig.json wusdt-export/
cp tailwind.config.ts wusdt-export/
cp postcss.config.js wusdt-export/
cp components.json wusdt-export/
cp drizzle.config.ts wusdt-export/
cp netlify.toml wusdt-export/
cp vercel.json wusdt-export/
cp README-DEPLOY.md wusdt-export/
cp download-instructions.md wusdt-export/

# Create README
cat > wusdt-export/README.md << 'EOF'
# Wrapped USDT (Wormhole) - wUSDT Website

Bu proje Wrapped USDT token'ı için profesyonel bir website içerir.

## Özellikler
- Token bilgileri ve kontrat adresi
- Kapsamlı whitepaper (10B arz, 2B Jupiter likidite)
- Responsive tasarım
- Social media entegrasyonu
- Ücretsiz hosting desteği

## Kurulum
```bash
npm install
npm run dev
```

## Deploy
Netlify, Vercel veya GitHub Pages'te ücretsiz deploy edebilirsiniz.
Detaylar için README-DEPLOY.md dosyasını okuyun.

## İletişim
- Email: ericwillines@gmail.com
- Twitter: https://x.com/wrappedwusdt
- Telegram: https://t.me/wrappedusdt
- Contract: 57GajvDHazpCCCCpKgiHppJJf5cjwHWancCZZLPoeFMj
EOF

echo "Export completed in wusdt-export/ directory"
echo "You can download all files from the wusdt-export folder"