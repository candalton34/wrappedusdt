# Wrapped USDT (Wormhole) - wUSDT Website

Bu proje Wrapped USDT token'ı için profesyonel bir website içerir.

## Özellikler
- Token bilgileri ve kontrat adresi
- Kapsamlı whitepaper (10B arz, 2B Jupiter likidite)
- Responsive tasarım
- Social media entegrasyonu
- Ücretsiz hosting desteği

## Kurulum
```bash
npm install
npm run dev
```

## Deploy
Netlify, Vercel veya GitHub Pages'te ücretsiz deploy edebilirsiniz.
Detaylar için README-DEPLOY.md dosyasını okuyun.

## İletişim
- Email: ericwillines@gmail.com
- Twitter: https://x.com/wrappedwusdt
- Telegram: https://t.me/wrappedusdt
- Contract: 57GajvDHazpCCCCpKgiHppJJf5cjwHWancCZZLPoeFMj
