import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ArrowLeft, Download, Shield, Zap, Coins, TrendingUp, Users, Globe, Lock } from "lucide-react";
import { Link } from "wouter";

export default function Whitepaper() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <Link href="/">
              <div className="flex items-center space-x-3 cursor-pointer">
                <img 
                  src="/attached_assets/WRAPPEDUSDT_1750788219349.png" 
                  alt="wUSDT Logo" 
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <h1 className="text-xl font-bold text-gray-900">wUSDT</h1>
                  <p className="text-xs text-gray-500">Wrapped USDT</p>
                </div>
              </div>
            </Link>
            <Link href="/">
              <Button variant="outline" className="flex items-center space-x-2">
                <ArrowLeft className="w-4 h-4" />
                <span>Back to Home</span>
              </Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Header */}
      <section className="bg-gradient-to-br from-tether-50 to-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Badge className="mb-4 bg-tether-100 text-tether-800 border-tether-200">Technical Documentation</Badge>
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-4">
            wUSDT Whitepaper
          </h1>
          <p className="text-xl text-gray-600 mb-8">
            Wrapped USDT (Wormhole): Bridging Stability Across Blockchains
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button className="bg-tether-600 hover:bg-tether-700 text-white">
              <Download className="w-4 h-4 mr-2" />
              Download PDF
            </Button>
          </div>
        </div>
      </section>

      {/* Content */}
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="prose prose-lg max-w-none">
          
          {/* Executive Summary */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-tether-600">Executive Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-700 leading-relaxed">
                Wrapped USDT (wUSDT) represents a revolutionary approach to cross-chain stablecoin accessibility, 
                bringing the reliability and widespread adoption of Tether's USDT to the high-performance Solana ecosystem. 
                Built on Wormhole's proven bridge infrastructure, wUSDT enables seamless value transfer while maintaining 
                the stability and trust that has made USDT the world's leading stablecoin.
              </p>
              <p className="text-gray-700 leading-relaxed">
                With a total supply of 10 billion tokens and strategic liquidity deployment, wUSDT is positioned to 
                become the cornerstone of DeFi operations on Solana, offering users unprecedented speed, low costs, 
                and cross-chain compatibility.
              </p>
            </CardContent>
          </Card>

          {/* Token Economics */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-tether-600">Token Economics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Supply Distribution</h4>
                  <div className="space-y-3">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Total Supply</span>
                      <span className="text-tether-600 font-bold">10,000,000,000 wUSDT</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-tether-50 rounded-lg">
                      <span className="font-medium">Jupiter DEX Liquidity</span>
                      <span className="text-tether-600 font-bold">2,000,000,000 wUSDT (20%)</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Bridge Reserve</span>
                      <span className="text-tether-600 font-bold">3,000,000,000 wUSDT (30%)</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Ecosystem Development</span>
                      <span className="text-tether-600 font-bold">2,500,000,000 wUSDT (25%)</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Strategic Partnerships</span>
                      <span className="text-tether-600 font-bold">1,500,000,000 wUSDT (15%)</span>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                      <span className="font-medium">Treasury & Operations</span>
                      <span className="text-tether-600 font-bold">1,000,000,000 wUSDT (10%)</span>
                    </div>
                  </div>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Key Metrics</h4>
                  <div className="space-y-4">
                    <div className="p-4 border border-tether-200 rounded-lg">
                      <div className="text-sm text-gray-600">Collateralization Ratio</div>
                      <div className="text-2xl font-bold text-tether-600">1:1</div>
                      <div className="text-sm text-gray-500">Fully backed by USDT</div>
                    </div>
                    <div className="p-4 border border-tether-200 rounded-lg">
                      <div className="text-sm text-gray-600">Bridge Protocol</div>
                      <div className="text-xl font-bold text-gray-900">Wormhole</div>
                      <div className="text-sm text-gray-500">Proven cross-chain infrastructure</div>
                    </div>
                    <div className="p-4 border border-tether-200 rounded-lg">
                      <div className="text-sm text-gray-600">Primary Blockchain</div>
                      <div className="text-xl font-bold text-gray-900">Solana</div>
                      <div className="text-sm text-gray-500">High-speed, low-cost transactions</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Technology Stack */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-tether-600">Technology & Infrastructure</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                <div className="text-center p-6 border border-gray-200 rounded-lg">
                  <Shield className="w-12 h-12 text-tether-600 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold mb-2">Wormhole Bridge</h4>
                  <p className="text-gray-600 text-sm">
                    Industry-leading cross-chain protocol with battle-tested security and $25B+ in volume processed.
                  </p>
                </div>
                <div className="text-center p-6 border border-gray-200 rounded-lg">
                  <Zap className="w-12 h-12 text-tether-600 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold mb-2">Solana Network</h4>
                  <p className="text-gray-600 text-sm">
                    Sub-second finality with transaction costs under $0.01, enabling microtransactions and high-frequency trading.
                  </p>
                </div>
                <div className="text-center p-6 border border-gray-200 rounded-lg">
                  <Lock className="w-12 h-12 text-tether-600 mx-auto mb-4" />
                  <h4 className="text-lg font-semibold mb-2">Smart Contracts</h4>
                  <p className="text-gray-600 text-sm">
                    Audited smart contracts ensuring transparent minting, burning, and cross-chain operations.
                  </p>
                </div>
              </div>
              
              <div className="space-y-6">
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">Cross-Chain Compatibility</h4>
                  <p className="text-gray-700 mb-4">
                    wUSDT leverages Wormhole's extensive network to enable seamless transfers between multiple blockchains:
                  </p>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    {['Ethereum', 'Solana', 'Polygon', 'Avalanche', 'BSC', 'Fantom', 'Arbitrum', 'Optimism'].map((chain) => (
                      <div key={chain} className="p-2 bg-gray-50 rounded text-center text-sm font-medium">
                        {chain}
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Use Cases */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-tether-600">Use Cases & Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <TrendingUp className="w-5 h-5 text-tether-600 mr-2" />
                    DeFi Applications
                  </h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• Automated Market Making (AMM) on Jupiter and Raydium</li>
                    <li>• Lending and borrowing protocols</li>
                    <li>• Yield farming and liquidity mining</li>
                    <li>• Synthetic asset creation and trading</li>
                    <li>• Cross-chain arbitrage opportunities</li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4 flex items-center">
                    <Users className="w-5 h-5 text-tether-600 mr-2" />
                    Commercial Applications
                  </h4>
                  <ul className="space-y-2 text-gray-700">
                    <li>• E-commerce payment processing</li>
                    <li>• Remittances and cross-border transfers</li>
                    <li>• Merchant payment solutions</li>
                    <li>• Treasury management for DAOs</li>
                    <li>• Institutional trading and settlement</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Jupiter Integration */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-tether-600">Jupiter DEX Integration</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-6 bg-gradient-to-r from-purple-50 to-blue-50 rounded-lg border border-purple-200">
                  <h4 className="text-lg font-semibold text-gray-900 mb-3">Liquidity Partnership</h4>
                  <p className="text-gray-700 mb-4">
                    2 billion wUSDT tokens have been strategically allocated to Jupiter DEX to ensure deep liquidity 
                    and optimal trading conditions for users. This partnership establishes wUSDT as a core trading pair 
                    within Solana's premier aggregation protocol.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                      <div className="text-2xl font-bold text-purple-600">$2B</div>
                      <div className="text-sm text-gray-600">Initial Liquidity</div>
                    </div>
                    <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                      <div className="text-2xl font-bold text-purple-600">0.1%</div>
                      <div className="text-sm text-gray-600">Target Slippage</div>
                    </div>
                    <div className="text-center p-4 bg-white rounded-lg shadow-sm">
                      <div className="text-2xl font-bold text-purple-600">24/7</div>
                      <div className="text-sm text-gray-600">Market Access</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Roadmap */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-tether-600">Roadmap & Future Development</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-8">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-tether-600 text-white rounded-full flex items-center justify-center text-sm font-bold">Q1</div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">Launch & Foundation</h4>
                    <ul className="text-gray-700 space-y-1 mt-2">
                      <li>• Token deployment and Jupiter liquidity provision</li>
                      <li>• Community building and ecosystem partnerships</li>
                      <li>• Integration with major Solana DeFi protocols</li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-tether-500 text-white rounded-full flex items-center justify-center text-sm font-bold">Q2</div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">Expansion & Utility</h4>
                    <ul className="text-gray-700 space-y-1 mt-2">
                      <li>• Cross-chain bridge optimization and fee reduction</li>
                      <li>• Mobile wallet integrations and user experience improvements</li>
                      <li>• Institutional adoption and custody solutions</li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-tether-400 text-white rounded-full flex items-center justify-center text-sm font-bold">Q3</div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">Innovation & Scale</h4>
                    <ul className="text-gray-700 space-y-1 mt-2">
                      <li>• Advanced DeFi products and yield strategies</li>
                      <li>• Layer 2 integrations and additional chain support</li>
                      <li>• Developer tools and SDK for third-party integrations</li>
                    </ul>
                  </div>
                </div>
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0 w-8 h-8 bg-tether-300 text-white rounded-full flex items-center justify-center text-sm font-bold">Q4</div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900">Global Adoption</h4>
                    <ul className="text-gray-700 space-y-1 mt-2">
                      <li>• Enterprise payment solutions and B2B integrations</li>
                      <li>• Regulatory compliance and institutional grade features</li>
                      <li>• Global merchant adoption and payment processor partnerships</li>
                    </ul>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Security & Compliance */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-tether-600">Security & Compliance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Security Measures</h4>
                  <ul className="space-y-3 text-gray-700">
                    <li className="flex items-start space-x-3">
                      <Shield className="w-5 h-5 text-tether-600 mt-0.5 flex-shrink-0" />
                      <span>Multi-signature treasury management with time-locked operations</span>
                    </li>
                    <li className="flex items-start space-x-3">
                      <Shield className="w-5 h-5 text-tether-600 mt-0.5 flex-shrink-0" />
                      <span>Regular smart contract audits by leading security firms</span>
                    </li>
                    <li className="flex items-start space-x-3">
                      <Shield className="w-5 h-5 text-tether-600 mt-0.5 flex-shrink-0" />
                      <span>Real-time monitoring and automated incident response</span>
                    </li>
                    <li className="flex items-start space-x-3">
                      <Shield className="w-5 h-5 text-tether-600 mt-0.5 flex-shrink-0" />
                      <span>Transparent reserve verification and public attestation</span>
                    </li>
                  </ul>
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Compliance Framework</h4>
                  <ul className="space-y-3 text-gray-700">
                    <li className="flex items-start space-x-3">
                      <Globe className="w-5 h-5 text-tether-600 mt-0.5 flex-shrink-0" />
                      <span>AML/KYC integration for institutional users</span>
                    </li>
                    <li className="flex items-start space-x-3">
                      <Globe className="w-5 h-5 text-tether-600 mt-0.5 flex-shrink-0" />
                      <span>Regulatory compliance across multiple jurisdictions</span>
                    </li>
                    <li className="flex items-start space-x-3">
                      <Globe className="w-5 h-5 text-tether-600 mt-0.5 flex-shrink-0" />
                      <span>Regular compliance audits and reporting</span>
                    </li>
                    <li className="flex items-start space-x-3">
                      <Globe className="w-5 h-5 text-tether-600 mt-0.5 flex-shrink-0" />
                      <span>Collaboration with financial regulators and law enforcement</span>
                    </li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Team & Contact */}
          <Card className="mb-12">
            <CardHeader>
              <CardTitle className="text-2xl text-tether-600">Team & Contact Information</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="p-6 bg-gray-50 rounded-lg">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">Development Team</h4>
                  <p className="text-gray-700 mb-4">
                    The wUSDT project is developed by a team of experienced blockchain engineers and DeFi specialists 
                    with extensive backgrounds in cross-chain protocols, stablecoin mechanisms, and Solana ecosystem development.
                  </p>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-1">Project Contact</p>
                      <p className="text-sm text-gray-600">ericwillines@gmail.com</p>
                    </div>
                    <div>
                      <p className="text-sm font-medium text-gray-700 mb-1">Owner Address</p>
                      <code className="text-xs font-mono text-gray-600 break-all">HJdkDSZpCPxG38t4DdPN5FNxByCfXRhGvvgd3cvNa7Ud</code>
                    </div>
                  </div>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Social Media</h4>
                    <div className="space-y-2">
                      <a href="https://x.com/wrappedwusdt" target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 text-tether-600 hover:text-tether-700">
                        <span>Twitter/X: @wrappedwusdt</span>
                      </a>
                      <a href="https://t.me/wrappedusdt" target="_blank" rel="noopener noreferrer" className="flex items-center space-x-2 text-tether-600 hover:text-tether-700">
                        <span>Telegram: @wrappedusdt</span>
                      </a>
                    </div>
                  </div>
                  <div>
                    <h4 className="text-lg font-semibold text-gray-900 mb-3">Contract Information</h4>
                    <div className="space-y-2">
                      <div>
                        <p className="text-sm font-medium text-gray-700">Contract Address</p>
                        <code className="text-xs font-mono text-gray-600 break-all">57GajvDHazpCCCCpKgiHppJJf5cjwHWancCZZLPoeFMj</code>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Disclaimer */}
          <Card className="bg-gray-50 border-gray-200">
            <CardContent className="p-6">
              <h4 className="text-lg font-semibold text-gray-900 mb-3">Important Disclaimer</h4>
              <p className="text-sm text-gray-600 leading-relaxed">
                This whitepaper is for informational purposes only and does not constitute investment advice, 
                financial advice, trading advice, or any other sort of advice. wUSDT tokens are utility tokens 
                designed for use within the Solana DeFi ecosystem. Past performance is not indicative of future results. 
                Cryptocurrency investments carry significant risk, including the potential loss of principal. 
                Please conduct your own research and consult with qualified financial advisors before making any investment decisions.
              </p>
            </CardContent>
          </Card>

        </div>
      </div>
    </div>
  );
}