import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { 
  Copy, 
  Shield, 
  Zap, 
  Coins, 
  ArrowUpDown, 
  Lock, 
  TrendingUp,
  ExternalLink,
  FileText,
  Download
} from "lucide-react";
import { SiX, SiTelegram } from "react-icons/si";
import { Link } from "wouter";

const CONTRACT_ADDRESS = "57GajvDHazpCCCCpKgiHppJJf5cjwHWancCZZLPoeFMj";

export default function Home() {
  const { toast } = useToast();
  const [copiedAddress, setCopiedAddress] = useState(false);

  const copyToClipboard = async () => {
    try {
      await navigator.clipboard.writeText(CONTRACT_ADDRESS);
      setCopiedAddress(true);
      toast({
        title: "Address Copied!",
        description: "Contract address has been copied to clipboard.",
      });
      setTimeout(() => setCopiedAddress(false), 2000);
    } catch (err) {
      toast({
        title: "Copy Failed",
        description: "Failed to copy address. Please copy manually.",
        variant: "destructive",
      });
    }
  };

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      const offsetTop = element.offsetTop - 80;
      window.scrollTo({
        top: offsetTop,
        behavior: 'smooth'
      });
    }
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="bg-white shadow-sm border-b border-gray-100 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <img 
                src="/attached_assets/WRAPPEDUSDT_1750788219349.png" 
                alt="wUSDT Logo" 
                className="w-10 h-10 rounded-full"
              />
              <div>
                <h1 className="text-xl font-bold text-gray-900">wUSDT</h1>
                <p className="text-xs text-gray-500">Wrapped USDT</p>
              </div>
            </div>
            <div className="hidden md:flex space-x-8">
              <button 
                onClick={() => scrollToSection('about')}
                className="text-gray-700 hover:text-tether-600 transition-colors"
              >
                About
              </button>
              <button 
                onClick={() => scrollToSection('features')}
                className="text-gray-700 hover:text-tether-600 transition-colors"
              >
                Features
              </button>
              <button 
                onClick={() => scrollToSection('how-to-buy')}
                className="text-gray-700 hover:text-tether-600 transition-colors"
              >
                How to Buy
              </button>
              <Link href="/whitepaper">
                <button className="text-gray-700 hover:text-tether-600 transition-colors">
                  Whitepaper
                </button>
              </Link>
              <button 
                onClick={() => scrollToSection('community')}
                className="text-gray-700 hover:text-tether-600 transition-colors"
              >
                Community
              </button>
            </div>
            <div className="flex items-center space-x-4">
              <a 
                href="https://x.com/wrappedwusdt" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-600 hover:text-tether-600 transition-colors"
              >
                <SiX className="w-5 h-5" />
              </a>
              <a 
                href="https://t.me/wrappedusdt" 
                target="_blank" 
                rel="noopener noreferrer" 
                className="text-gray-600 hover:text-tether-600 transition-colors"
              >
                <SiTelegram className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-tether-50 to-white">
        {/* Background decoration */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-20 left-20 w-32 h-32 rounded-full border-4 border-tether-500"></div>
          <div className="absolute top-40 right-32 w-24 h-24 rounded-full border-2 border-tether-300"></div>
          <div className="absolute bottom-20 left-1/3 w-16 h-16 rounded-full border-2 border-tether-400"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-24">
          <div className="text-center">
            <div className="mb-8">
              <img 
                src="/attached_assets/WRAPPEDUSDT_1750788219349.png" 
                alt="wUSDT Logo" 
                className="w-20 h-20 rounded-full mx-auto mb-6"
              />
            </div>
            <h1 className="text-5xl md:text-6xl font-bold text-gray-900 mb-6">
              Wrapped USDT
              <span className="block text-tether-600">Wormhole</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto">
              Experience seamless cross-chain USDT transactions with wUSDT. Built on Wormhole bridge technology for secure, efficient DeFi operations on Solana.
            </p>
            
            {/* Contract Address Display */}
            <Card className="max-w-4xl mx-auto mb-8 border border-gray-100">
              <CardContent className="p-6">
                <div className="flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="flex-1">
                    <p className="text-sm font-medium text-gray-700 mb-2">Contract Address</p>
                    <div className="flex items-center gap-3">
                      <code className="text-sm md:text-base font-mono bg-gray-50 px-4 py-2 rounded-lg border text-gray-800 break-all">
                        {CONTRACT_ADDRESS}
                      </code>
                      <Button 
                        onClick={copyToClipboard}
                        className={`flex-shrink-0 ${copiedAddress ? 'bg-green-600 hover:bg-green-700' : 'bg-tether-600 hover:bg-tether-700'} text-white`}
                      >
                        <Copy className="w-4 h-4 mr-2" />
                        <span className="hidden sm:inline">{copiedAddress ? 'Copied!' : 'Copy'}</span>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* CTA Buttons */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
              <Button 
                onClick={() => scrollToSection('how-to-buy')}
                className="bg-tether-600 hover:bg-tether-700 text-white px-8 py-4 text-lg h-auto"
              >
                How to Buy wUSDT
              </Button>
              <Link href="/whitepaper">
                <Button 
                  variant="outline" 
                  className="border-2 border-tether-600 text-tether-600 hover:bg-tether-50 px-8 py-4 text-lg h-auto"
                >
                  <FileText className="w-5 h-5 mr-2" />
                  Read Whitepaper
                </Button>
              </Link>
              <Button 
                onClick={() => {
                  window.open('/api/download/source', '_blank');
                }}
                variant="outline" 
                className="border-2 border-gray-600 text-gray-600 hover:bg-gray-50 px-8 py-4 text-lg h-auto"
              >
                <Download className="w-5 h-5 mr-2" />
                Download Source
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <Card className="text-center shadow-lg">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-tether-600 mb-2">1:1</div>
                <div className="text-gray-600">Pegged to USDT</div>
              </CardContent>
            </Card>
            <Card className="text-center shadow-lg">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-tether-600 mb-2">Solana</div>
                <div className="text-gray-600">Blockchain</div>
              </CardContent>
            </Card>
            <Card className="text-center shadow-lg">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-tether-600 mb-2">Wormhole</div>
                <div className="text-gray-600">Bridge Protocol</div>
              </CardContent>
            </Card>
            <Card className="text-center shadow-lg">
              <CardContent className="p-6">
                <div className="text-3xl font-bold text-tether-600 mb-2">DeFi</div>
                <div className="text-gray-600">Ready</div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">About Wrapped USDT</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              wUSDT brings the stability of USDT to the Solana ecosystem through Wormhole's secure bridging technology.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <img 
                src="https://images.unsplash.com/photo-1642790106117-e829e14a795f?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=800&h=600" 
                alt="Cryptocurrency trading and DeFi platform interface" 
                className="rounded-2xl shadow-2xl w-full"
              />
            </div>
            <div className="space-y-6">
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-tether-100 rounded-xl flex items-center justify-center">
                  <Shield className="text-tether-600 w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Secure Bridge Technology</h3>
                  <p className="text-gray-600">Built on Wormhole's battle-tested bridge infrastructure, ensuring maximum security for cross-chain operations.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-tether-100 rounded-xl flex items-center justify-center">
                  <Zap className="text-tether-600 w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">Lightning Fast</h3>
                  <p className="text-gray-600">Experience near-instant transactions with minimal fees on the Solana blockchain.</p>
                </div>
              </div>
              <div className="flex items-start space-x-4">
                <div className="flex-shrink-0 w-12 h-12 bg-tether-100 rounded-xl flex items-center justify-center">
                  <Coins className="text-tether-600 w-6 h-6" />
                </div>
                <div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">DeFi Compatible</h3>
                  <p className="text-gray-600">Seamlessly integrate with Solana's thriving DeFi ecosystem for lending, trading, and yield farming.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-gradient-to-br from-gray-50 to-tether-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">Key Features</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Discover what makes wUSDT the preferred choice for cross-chain stablecoin operations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-tether-100 rounded-2xl flex items-center justify-center mb-6">
                  <ArrowUpDown className="text-tether-600 w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Cross-Chain Bridge</h3>
                <p className="text-gray-600">Seamlessly move your USDT between different blockchains using Wormhole's trusted infrastructure.</p>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-tether-100 rounded-2xl flex items-center justify-center mb-6">
                  <Lock className="text-tether-600 w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">Fully Collateralized</h3>
                <p className="text-gray-600">Every wUSDT token is backed 1:1 by USDT held securely in the Wormhole bridge contract.</p>
              </CardContent>
            </Card>

            <Card className="shadow-lg hover:shadow-xl transition-shadow">
              <CardContent className="p-8">
                <div className="w-16 h-16 bg-tether-100 rounded-2xl flex items-center justify-center mb-6">
                  <TrendingUp className="text-tether-600 w-8 h-8" />
                </div>
                <h3 className="text-2xl font-bold text-gray-900 mb-4">DeFi Integration</h3>
                <p className="text-gray-600">Use wUSDT across Solana's DeFi protocols for trading, lending, and yield generation opportunities.</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* How to Buy Section */}
      <section id="how-to-buy" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 mb-6">How to Get wUSDT</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              Follow these simple steps to acquire and start using wUSDT in your DeFi operations.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-tether-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 text-2xl font-bold">1</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Set Up Wallet</h3>
              <p className="text-gray-600">Install and configure a Solana-compatible wallet like Phantom, Solflare, or Backpack.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-tether-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 text-2xl font-bold">2</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Bridge USDT</h3>
              <p className="text-gray-600">Use Wormhole Connect to bridge your USDT from Ethereum or other supported chains to Solana.</p>
            </div>

            <div className="text-center">
              <div className="w-16 h-16 bg-tether-600 text-white rounded-2xl flex items-center justify-center mx-auto mb-6 text-2xl font-bold">3</div>
              <h3 className="text-2xl font-bold text-gray-900 mb-4">Start Trading</h3>
              <p className="text-gray-600">Trade wUSDT on Solana DEXes or use it in DeFi protocols for lending and yield farming.</p>
            </div>
          </div>

          <div className="mt-16 bg-gradient-to-r from-tether-600 to-tether-700 rounded-2xl p-8 text-white text-center">
            <h3 className="text-2xl font-bold mb-4">Ready to Bridge?</h3>
            <p className="text-tether-100 mb-6">Connect to Wormhole Portal and start bridging your USDT to Solana today.</p>
            <Button asChild className="bg-white text-tether-600 hover:bg-gray-100">
              <a href="https://portalbridge.com/" target="_blank" rel="noopener noreferrer">
                Open Wormhole Portal
                <ExternalLink className="w-4 h-4 ml-2" />
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Community Section */}
      <section id="community" className="py-20 bg-gray-900 text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-4xl font-bold mb-6">Join the Community</h2>
          <p className="text-xl text-gray-300 mb-12 max-w-3xl mx-auto">
            Connect with the wUSDT community and stay updated on the latest developments, partnerships, and opportunities.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="bg-gray-800 hover:bg-gray-700 transition-colors border-gray-700">
              <CardContent className="p-8">
                <a href="https://x.com/wrappedwusdt" target="_blank" rel="noopener noreferrer" className="block group">
                  <div className="flex items-center justify-center mb-6">
                    <SiX className="w-12 h-12 text-blue-400" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Follow on Twitter</h3>
                  <p className="text-gray-400 group-hover:text-gray-300">Get real-time updates, announcements, and community discussions.</p>
                </a>
              </CardContent>
            </Card>

            <Card className="bg-gray-800 hover:bg-gray-700 transition-colors border-gray-700">
              <CardContent className="p-8">
                <a href="https://t.me/wrappedusdt" target="_blank" rel="noopener noreferrer" className="block group">
                  <div className="flex items-center justify-center mb-6">
                    <SiTelegram className="w-12 h-12 text-blue-500" />
                  </div>
                  <h3 className="text-2xl font-bold mb-4">Join Telegram</h3>
                  <p className="text-gray-400 group-hover:text-gray-300">Connect directly with the team and community members.</p>
                </a>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-white border-t border-gray-200 py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src="/attached_assets/WRAPPEDUSDT_1750788219349.png" 
                  alt="wUSDT Logo" 
                  className="w-10 h-10 rounded-full"
                />
                <div>
                  <h3 className="text-xl font-bold text-gray-900">wUSDT</h3>
                  <p className="text-sm text-gray-500">Wrapped USDT (Wormhole)</p>
                </div>
              </div>
              <p className="text-gray-600 mb-6 max-w-md">
                Bringing the stability of USDT to Solana through secure, efficient cross-chain bridging technology.
              </p>
              <div className="flex space-x-4">
                <a 
                  href="https://x.com/wrappedwusdt" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-10 h-10 bg-gray-100 hover:bg-tether-100 rounded-lg flex items-center justify-center transition-colors"
                >
                  <SiX className="w-5 h-5 text-gray-600 hover:text-tether-600" />
                </a>
                <a 
                  href="https://t.me/wrappedusdt" 
                  target="_blank" 
                  rel="noopener noreferrer" 
                  className="w-10 h-10 bg-gray-100 hover:bg-tether-100 rounded-lg flex items-center justify-center transition-colors"
                >
                  <SiTelegram className="w-5 h-5 text-gray-600 hover:text-tether-600" />
                </a>
              </div>
            </div>

            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Resources</h4>
              <ul className="space-y-2">
                <li>
                  <button 
                    onClick={() => scrollToSection('about')}
                    className="text-gray-600 hover:text-tether-600 transition-colors"
                  >
                    About wUSDT
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('features')}
                    className="text-gray-600 hover:text-tether-600 transition-colors"
                  >
                    Features
                  </button>
                </li>
                <li>
                  <button 
                    onClick={() => scrollToSection('how-to-buy')}
                    className="text-gray-600 hover:text-tether-600 transition-colors"
                  >
                    How to Buy
                  </button>
                </li>
                <li>
                  <Link href="/whitepaper">
                    <button className="text-gray-600 hover:text-tether-600 transition-colors">
                      Whitepaper
                    </button>
                  </Link>
                </li>
                <li>
                  <button 
                    onClick={() => {
                      window.open('/api/download/source', '_blank');
                    }}
                    className="text-gray-600 hover:text-tether-600 transition-colors"
                  >
                    Download Source
                  </button>
                </li>
                <li>
                  <a 
                    href="https://portalbridge.com/" 
                    target="_blank" 
                    rel="noopener noreferrer" 
                    className="text-gray-600 hover:text-tether-600 transition-colors"
                  >
                    Wormhole Portal
                  </a>
                </li>
              </ul>
            </div>

            <div>
              <h4 className="text-lg font-semibold text-gray-900 mb-4">Contact</h4>
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Email</p>
                  <p className="text-sm text-gray-600">ericwillines@gmail.com</p>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Owner Address</p>
                  <code className="text-xs font-mono text-gray-600 break-all">HJdkDSZpCPxG38t4DdPN5FNxByCfXRhGvvgd3cvNa7Ud</code>
                </div>
                <div>
                  <p className="text-sm font-medium text-gray-700 mb-1">Contract Address</p>
                  <code className="text-xs font-mono text-gray-600 break-all">{CONTRACT_ADDRESS}</code>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-gray-200 mt-12 pt-8 text-center">
            <p className="text-gray-500">© 2024 Wrapped USDT (Wormhole). Built on Solana with Wormhole bridge technology.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
