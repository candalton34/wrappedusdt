# Wrapped USDT (Wormhole) - wUSDT Official Website

🚀 **Professional cryptocurrency website for Wrapped USDT token on Solana**

## 🌟 Features

- **Token Information**: Complete details about wUSDT (Wrapped USDT)
- **Whitepaper**: Comprehensive documentation with tokenomics
- **10B Total Supply**: 2B locked liquidity on Jupiter DEX
- **Cross-chain**: Built on Wormhole bridge technology
- **Responsive Design**: Mobile-first approach with Tether green theme
- **Social Integration**: Twitter and Telegram links
- **Download Source**: Visitors can download project source code

## 🔗 Token Details

- **Contract Address**: `57GajvDHazpCCCCpKgiHppJJf5cjwHWancCZZLPoeFMj`
- **Owner Address**: `HJdkDSZpCPxG38t4DdPN5FNxByCfXRhGvvgd3cvNa7Ud`
- **Blockchain**: Solana
- **Bridge**: Wormhole Protocol
- **Total Supply**: 10,000,000,000 wUSDT
- **Jupiter Liquidity**: 2,000,000,000 wUSDT (20%)

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript
- **Styling**: Tailwind CSS + shadcn/ui
- **Build Tool**: Vite
- **Routing**: Wouter
- **State Management**: TanStack Query
- **Icons**: Lucide React + React Icons

## 🚀 Quick Start

### Development
```bash
npm install
npm run dev
```

### Production Build
```bash
npm run build
npm start
```

## 🌐 Deployment

### Netlify (Recommended)
1. Connect this GitHub repository to Netlify
2. Build settings are configured in `netlify.toml`
3. Automatic deployments on push to main branch

### Vercel
1. Import this repository to Vercel
2. Settings configured in `vercel.json`
3. Deploy with zero configuration

### GitHub Pages
1. Enable GitHub Pages in repository settings
2. Use GitHub Actions workflow (see deployment guide)

## 📁 Project Structure

```
├── client/                 # Frontend application
│   ├── src/
│   │   ├── pages/         # React pages (home, whitepaper)
│   │   ├── components/    # UI components (shadcn/ui)
│   │   ├── hooks/         # Custom React hooks
│   │   └── lib/           # Utilities and API client
│   ├── index.html         # HTML template
│   └── public/            # Static assets
├── server/                # Express.js backend
├── shared/                # Shared types and schemas
├── attached_assets/       # Token logos and images
└── deploy configs         # netlify.toml, vercel.json
```

## 🔗 Links

- **Website**: [Coming Soon]
- **Twitter**: https://x.com/wrappedwusdt
- **Telegram**: https://t.me/wrappedusdt
- **Email**: ericwillines@gmail.com

## 🎨 Design

- **Primary Color**: Tether Green (#26a69a)
- **Typography**: Inter font family
- **Theme**: Professional crypto/DeFi aesthetic
- **Responsive**: Desktop, tablet, and mobile optimized

## 📄 Pages

1. **Home** (`/`): Token overview, stats, features, how to buy
2. **Whitepaper** (`/whitepaper`): Complete technical documentation

## ⚡ Performance

- **Fast Loading**: Optimized Vite build
- **SEO Optimized**: Meta tags and Open Graph
- **Accessible**: WCAG compliant components
- **Mobile Fast**: Responsive design

## 🤝 Contributing

This is the official wUSDT website repository. For issues or suggestions, contact the team.

## 📜 License

MIT License - Built for the wUSDT community

---

**Wrapped USDT (Wormhole)** - Bringing USDT stability to Solana with lightning speed and minimal fees.