# GitHub Repository Setup Guide

## 🔧 Setup Tamamlandı ✅

Git repository başarıyla hazırlandı. Şimdi GitHub'da repository oluşturup yükleyin:

## 📋 Adım Adım GitHub Yükleme

### 1. GitHub'da Yeni Repository Oluşturun
1. [GitHub.com](https://github.com)'a gidin
2. "+" butonuna tıklayın → "New repository"
3. Repository name: `wusdt-website` (veya istediğiniz isim)
4. Public/Private seçin (Public öneriyoruz deployment için)
5. **Initialize with README seçmeyin** (zaten var)
6. "Create repository" tıklayın

### 2. Repository'yi Bu Projeye Bağlayın
GitHub'da repository oluşturduktan sonra verilen komutları çalıştırın:

```bash
git remote add origin https://github.com/KULLANICI_ADINIZ/wusdt-website.git
git branch -M main
git push -u origin main
```

**NOT**: `KULLANICI_ADINIZ` yerine kendi GitHub kullanıcı adınızı yazın.

### 3. Replit Terminal'de Komutları Çalıştırın
Replit'teki Shell/Console sekmesinde:

```bash
# Repository'nizi bağlayın (GitHub'dan aldığınız URL ile)
git remote add origin https://github.com/KULLANICI_ADINIZ/wusdt-website.git

# Ana branch'i main olarak ayarlayın
git branch -M main

# Dosyaları GitHub'a yükleyin
git push -u origin main
```

## 🚀 Deploy Seçenekleri

### A) Netlify Deploy (Önerilen)
1. [Netlify.com](https://netlify.com) → "New site from Git"
2. GitHub hesabınızı bağlayın
3. `wusdt-website` repository'sini seçin
4. Build ayarları otomatik algılanacak
5. "Deploy site" tıklayın
6. **Sonuç**: `https://random-name.netlify.app`

### B) Vercel Deploy
1. [Vercel.com](https://vercel.com) → "New Project"
2. GitHub'ı bağlayın
3. Repository'yi seçin
4. Deploy başlayacak
5. **Sonuç**: `https://wusdt-website.vercel.app`

## 🎯 Deployment Sonrası

Deploy tamamlandığında:

1. **URL'nizi alın** (örn: `https://wusdt-xyz.netlify.app`)
2. **Card.co'da paylaşın**:
   - Card type: Website
   - Title: "Wrapped USDT (Wormhole) - wUSDT"
   - Description: "Cross-chain USDT on Solana. 10B supply, 2B Jupiter liquidity"
   - URL: Deploy URL'niz

## 🔗 Repository İçeriği

✅ Ana website (React + TypeScript)  
✅ Whitepaper sayfası  
✅ Token bilgileri ve iletişim  
✅ Download butonu (kaynak kod)  
✅ Deploy konfigürasyonları  
✅ Türkçe dokümantasyon  

## ❓ Sorun Yaşarsanız

1. **Git komutları hata verirse**: Repository URL'ini kontrol edin
2. **Deploy edilmiyorsa**: netlify.toml dosyası mevcut
3. **Build hata verirse**: Node.js 18+ gerekli

## 📞 İletişim

Deploy tamamlandığında URL'nizi paylaşabilirsiniz!